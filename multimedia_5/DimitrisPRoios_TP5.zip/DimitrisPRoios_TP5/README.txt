accessibe here:

https://colab.research.google.com/drive/1PWPG71FFBOEEc_2A4dEGMoske5DlTsyP


I wil update with exercise 2 also.


